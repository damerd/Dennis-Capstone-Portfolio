Algorithms and Data Structures
Damien Dennis

Original_Artifact contains the ClaimIntel main-branch snapshot used before Enhancement Two.
Enhanced_Artifact contains the milestone3-algorithms implementation.

Run algorithm tests from Enhanced_Artifact with:
npm install
npm run test:algorithms

Enhancement documentation:
Enhanced_Artifact/docs/CS499_Milestone_Three_Algorithms.md
